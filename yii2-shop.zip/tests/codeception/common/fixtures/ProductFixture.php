<?php

namespace tests\codeception\common\fixtures;

use yii\test\ActiveFixture;

/**
 * Product fixture
 */
class ProductFixture extends ActiveFixture
{
    public $modelClass = 'common\models\Product';
}
