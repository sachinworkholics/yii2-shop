<?php

namespace tests\codeception\common\fixtures;

use yii\test\ActiveFixture;

/**
 * Category fixture
 */
class CategoryFixture extends ActiveFixture
{
    public $modelClass = 'common\models\Category';
}
